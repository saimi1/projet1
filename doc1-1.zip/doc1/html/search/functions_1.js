var searchData=
[
  ['julia',['Julia',['../main_8cpp.html#a41a1eee46d58c45b131dc4336adae983',1,'main.cpp']]]
];
